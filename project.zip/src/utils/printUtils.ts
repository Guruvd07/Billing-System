import { BillingItem } from '../types/billing';

export const generateAndDownloadPDF = (items: BillingItem[], grandTotal: number, customerName: string): void => {
  const validItems = items.filter(item => item.name && item.total);
  
  const itemsHTML = validItems.map((item, index) => `
    <tr style="${index % 2 === 0 ? 'background-color: white;' : 'background-color: #f9fafb;'}">
      <td style="text-align: center; font-weight: 600;">${index + 1}</td>
      <td style="font-weight: 500;">${item.name}</td>
      <td style="text-align: center;">${item.quantity || '-'}</td>
      <td style="text-align: center;">₹${item.price || '-'}</td>
      <td style="text-align: center; font-weight: bold;">₹${Math.floor(parseFloat(item.total) || 0)}</td>
      <td style="text-align: center; font-weight: bold; color: #dc2626;">₹${item.decimal || '00'}</td>
    </tr>
  `).join('');

  // Add empty rows for consistent formatting
  const emptyRowsHTML = Array.from({ length: Math.max(0, 5 - validItems.length) }).map((_, index) => `
    <tr>
      <td style="text-align: center;">${validItems.length + index + 1}</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  `).join('');

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="hi">
    <head>
        <meta charset="UTF-8">
        <title>Narmada Traders - Bill</title>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;600;700&display=swap" rel="stylesheet">
        <style>
            body { 
                font-family: 'Noto Sans Devanagari', Arial, sans-serif; 
                margin: 0; 
                padding: 20px; 
                color: #000;
                line-height: 1.4;
            }
            .god-names {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 25px;
                font-size: 18px;
                font-weight: bold;
                color: #374151;
            }
            .god-names div {
                text-align: center;
            }
            .print-header { 
                text-align: center; 
                border-bottom: 4px solid #000; 
                padding-bottom: 20px; 
                margin-bottom: 30px; 
            }
            .print-company-name { 
                font-size: 36px; 
                font-weight: bold; 
                margin: 0 0 15px 0; 
                letter-spacing: 2px; 
                color: #1e40af;
            }
            .bill-info {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 25px;
            }
            .customer-info {
                text-align: left;
            }
            .signature-section {
                text-align: right;
            }
            .signature-line {
                border-bottom: 2px solid #000;
                width: 200px;
                height: 40px;
                margin-top: 10px;
                position: relative;
            }
            .signature-label {
                text-align: center;
                font-weight: bold;
                font-size: 16px;
                margin-bottom: 5px;
            }
            .print-table { 
                width: 100%; 
                border-collapse: collapse; 
                border: 2px solid #000; 
                margin-bottom: 25px; 
            }
            .print-table th, .print-table td { 
                border: 1px solid #000; 
                padding: 12px 8px; 
            }
            .print-table th { 
                background-color: #2563eb; 
                color: white;
                font-weight: bold; 
                font-size: 14px;
            }
            .print-total { 
                text-align: right; 
                margin-bottom: 30px; 
            }
            .total-box {
                display: inline-block;
                background-color: #2563eb;
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                font-size: 24px;
                font-weight: bold;
            }
            .print-footer { 
                text-align: center; 
                border-top: 2px solid #000; 
                padding-top: 20px; 
                margin-top: 40px; 
            }
            .footer-title {
                font-weight: bold;
                font-size: 18px;
                color: #1e40af;
                margin-bottom: 5px;
            }
        </style>
    </head>
    <body>
        <!-- Three God Names -->
        <div class="god-names">
            <div>॥ श्री गणेशाय नमः ॥</div>
            <div>॥ श्री सरस्वत्यै नमः ॥</div>
            <div>॥ श्री लक्ष्म्यै नमः ॥</div>
        </div>

        <!-- Company Header -->
        <div class="print-header">
            <h1 class="print-company-name">नर्मदा ट्रेडर्स</h1>
            <p style="font-size: 16px; margin: 10px 0 5px 0;">सोनई, त्रिमूर्ति थिएटर समोर , ता. नेवासा , जि. अहिल्यानगर</p>
            <p style="margin: 5px 0; font-weight: 600;">Phone: +91 9850732489 / +91 87654-32109</p>
            <p style="margin: 0; font-weight: 600;">सोनई, महाराष्ट्र - 414105</p>
        </div>

        <!-- Bill Info and Customer Details -->
        <div class="bill-info">
            <div class="customer-info">
                <p style="margin: 0 0 5px 0;"><strong>Bill No:</strong> NT-${Date.now().toString().slice(-6)}</p>
                <p style="margin: 0 0 5px 0;"><strong>Date:</strong> ${new Date().toLocaleDateString('hi-IN')}</p>
                <p style="margin: 0 0 15px 0;"><strong>Time:</strong> ${new Date().toLocaleTimeString('hi-IN')}</p>
                <p style="margin: 0; font-weight: bold; font-size: 18px;">ग्राहक: ${customerName}</p>
            </div>
            <div class="signature-section">
                <p style="margin: 0 0 10px 0; font-weight: bold; font-size: 18px;">Customer Copy</p>
                <div class="signature-label">हस्ते</div>
                <div class="signature-line"></div>
            </div>
        </div>

        <!-- Items Table -->
        <table class="print-table">
            <thead>
                <tr>
                    <th>अ.नं.</th>
                    <th>तपशील</th>
                    <th>नग</th>
                    <th>दर</th>
                    <th>रुपये</th>
                    <th>पैसे</th>
                </tr>
            </thead>
            <tbody>
                ${itemsHTML}
                ${emptyRowsHTML}
            </tbody>
        </table>

        <!-- Total Section -->
        <div class="print-total">
            <div class="total-box">
                एकूण रक्कम: ₹${grandTotal.toFixed(2)}
            </div>
        </div>

        <!-- Footer -->
        <div class="print-footer">
            <p class="footer-title">नर्मदा ट्रेडर्स निवडल्याबद्दल धन्यवाद!</p>
            <p style="margin: 0 0 15px 0; color: #666;">दर्जेदार फर्निचर आणि उपकरणासाठी पुन्हा भेट द्या</p>
            <p style="margin: 0 0 10px 0; font-size: 14px; color: #666;">
                टिप : एकदा विकलेला माल परत घेतला आणि बदलून दिला जाणार नाही.
            </p>
            <p style="margin: 0; font-size: 12px; color: #999;">
                This is a computer generated bill.
            </p>
        </div>
    </body>
    </html>
  `;

  // Create a blob and download it directly
  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  
  // Create a temporary link and trigger download
  const link = document.createElement('a');
  link.href = url;
  link.download = `Narmada_Traders_Bill_${customerName.replace(/\s+/g, '_')}_${Date.now()}.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Clean up the URL
  URL.revokeObjectURL(url);
  
  // Show success message
  alert('PDF बिल successfully download झाले!');
};

export const openPrintWindow = (htmlContent: string): void => {
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 500);
  }
};